// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");
const BigNumber = require('bignumber.js');

async function main() {

   //  const Tar = artifacts.require("Tollar");
   //  const Usr = artifacts.require("UsrStablecoin");
   //  const UsrIn = artifacts.require("UsrIncentive");
   //  const Pool = artifacts.require("UsrPool");
   //  let tar_addr = '0x32a2C78041991Be413e55580567948909911154D';
   //  let usr_addr = '0xDad785c864db82e79Fd410BDcDCD19900a69e09A';
   //  let usrIn_addr = '0x1ca416F8bCB7753f87E5ff3945cFED28C460bc79';
   //  let pool_addr = '0x0C702EAD8b654Cd92d277eaFE5924Ad24915a65a';
   //  // We get the contract to deploy
   //
   //  const tar = await Tar.at(tar_addr);
   //  const usr = await Usr.at(usr_addr);
   //  const usrIn = await UsrIn.at(usrIn_addr);
   //  const pool = await Pool.at(pool_addr);
   //
   //  await pool.setPoolParameters("1000000000",'0',2,5500,1194,5500,5500,'1000000000000000000000000');
   //  let _tar_usr_oracle = '0x54251F7BF10a6DeF2C2Ce9064fe7CC3651e645EC';
   //  let _usr_usd_oracle = '0x7D972c8a4eb43708aFD33B4cb47270d19736A395';
   //  let _tar_usr_24H_oracle = '0x34cC6bdbF4224e58D68C5BEcCb9105540fe6c5EE';
   //  let _usr_usd_24H_oracle = '0xfe9b2e0a324F48D1D954C1DEB60be27D1aF74bBC';
   //  await usr.setOracleAddress(_tar_usr_oracle, _usr_usd_oracle, _tar_usr_24H_oracle, _usr_usd_24H_oracle);
   // // await usr.addPool(pool_addr);
   //  const a = await usr.tar_usd_price();
   //  console.log("a",a)


    //npx hardhat run --network rinkeby scripts/set.js
    // npx hardhat run --network ropsten scripts/sample-script.js
    // npx hardhat run --network rinkeby scripts/sample-script.js
    // npx hardhat verify --network bsc_test 0xb41133a368CC9EE67a807a331dde6deC92C521a8 "0x442a05a9B2d5883ee1418d9411250E29021ca48C" "0x024C79c199C09104e43A89e457e7491f3548B9cA" "0x740012c9ca86f49f324de5de783b477d19fe3ea2" "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x8412ebf45bac1b340bbe8f318b928c466c4e39ca"
    const owner = "0x2287374e8d7090214628adad44Ff1ab56b9284D1";
    const Factory = artifacts.require("UniswapV2Factory");
     const _time_lock = "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"

    const Pair = artifacts.require("UniswapV2Pair");
    const factory = "0x5c69bee701ef814a2b6a3edd4b1652cb9cc5aa6f";

    const Pool = artifacts.require("UsrPoolLibrary");
    const pool = await Pool.at("0xf32ae14C2D4b240e236f2bd13F080EB48e96EBAA");
    const fac1 = await Factory.at(factory);
    const Usdc = artifacts.require("UsToken");
    const usdc = await Usdc.at("0xc87CeeFFB21751B9fb34c0Ad88B530157757E072");


    const Weth = await hre.ethers.getContractFactory("WETH");
    const weth = await Weth.deploy(owner);
    await weth.deployed();
    console.log("weth:", weth.address);
    let weth_address = weth.address;
    let coll_address = '0xc87CeeFFB21751B9fb34c0Ad88B530157757E072';
    await fac1.createPair(weth_address, coll_address);
    const weth_usdc_pair = await fac1.getPair(weth_address, coll_address);
    console.log("getPair:", weth_usdc_pair);
    const weth_usdc_pair_inst = await Pair.at(weth_usdc_pair);

    await usdc.transfer(weth_usdc_pair, "100000000");
    await weth.transfer(weth_usdc_pair, "100000000000000000000");
    await sleep(30000);
    await weth_usdc_pair_inst.mint(owner);

    const Weth_Usdc_oracle = await hre.ethers.getContractFactory("UniswapPairOracle_USDC_WETH");
    const weth_Usdc_oracle = await Weth_Usdc_oracle.deploy(factory, weth_address, coll_address, owner, _time_lock);
    await weth_Usdc_oracle.deployed();

    console.log("weth_Usdc_oracle:", weth_Usdc_oracle.address);

    await pool.setCollatETHOracle(weth_Usdc_oracle.address, weth_address);
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error(error);
        process.exit(1);
    });
