// We require the Hardhat Runtime Environment explicitly here. This is optional 
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");
const BigNumber = require('bignumber.js');

async function main() {


    // We get the contract to deploy
    const owner = "0x2287374e8d7090214628adad44Ff1ab56b9284D1";
    const factory = "0x5c69bee701ef814a2b6a3edd4b1652cb9cc5aa6f";
    const _time_lock = "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"

    const Factory = artifacts.require("UniswapV2Factory");
    const Pair = artifacts.require("UniswapV2Pair");
    //deploy usdt

    // const Usdc = await hre.ethers.getContractFactory("UsToken");
    // const usdc = await Usdc.deploy("Usdc", "USDC");
    // await usdc.deployed();
    // console.log("usdc address:", usdc.address);

    const Usdt = await hre.ethers.getContractFactory("UsToken");
    const usdt = await Usdt.deploy("Usdt", "USDT");
    await usdt.deployed();
    console.log("usdt address:", usdt.address);

    const Usr = await hre.ethers.getContractFactory("UsrStablecoin");
    const usr = await Usr.deploy("USR", "USR", owner, _time_lock);
    await usr.deployed();

    console.log("usr deployed to:", usr.address);

    const Tar = await hre.ethers.getContractFactory("Tollar");
    const tar = await Tar.deploy("tollar", "TAR", owner, _time_lock);
    await tar.deployed();

    console.log("tar deployed to:", tar.address);


    const UsrIn = await hre.ethers.getContractFactory("UsrIncentive");
    const usrIn = await UsrIn.deploy(owner, _time_lock, usr.address, tar.address);
    await usrIn.deployed();

    console.log("UsrIncentive deployed to:", usrIn.address);

    await usr.setIncentive(usrIn.address);
    await usr.setTarAddress(tar.address);
    await tar.setUSRAddress(usr.address);

    const incentiveAddress = await usrIn.getIncentiveAddress();
    await tar.setIntensiveAddress(incentiveAddress);

    const Library = await hre.ethers.getContractFactory("UsrPoolLibrary");
    const library = await Library.deploy();
    await library.deployed();
    console.log("library deployed to:", library.address);
    const PoolUsdc = await hre.ethers.getContractFactory(
        "Pool_USDC",
        {
            libraries: {
                UsrPoolLibrary: library.address
            }
        }
    );

    const pool = await PoolUsdc.deploy(usr.address, tar.address, usdt.address, owner, _time_lock);
    await pool.deployed();

    console.log("pool deployed to:", pool.address);

    await usr.addPool(pool.address);


    // let tar_addr = '0x44164f1F9Ff47fC47De414052F62a02385D31563';
    // let usr_addr = '0xDf4535bFa20e5803F4Bdd1071B5A4D8A0Fdd1d87';

    let tar_addr = tar.address;
    let usr_addr = usr.address;
    let usdt_addr = usdt.address;
    //add liquility and create pair
    const fac = await Factory.at(factory);
    await fac.createPair(tar_addr, usr_addr);
    let tar_usr_pair_address = await fac.getPair(tar_addr, usr_addr);
    console.log("get tar_usr_pair:", tar_usr_pair_address);

    await usrIn.setPair(tar_usr_pair_address, true);
    await usrIn.setTarUsrPair(tar_usr_pair_address);

    let pair = await Pair.at(tar_usr_pair_address);

    await tar.transfer(pair.address, "2000000000000000000000");
    // console.log("tar bal", b0.toString());
    await usr.transfer(pair.address, "2000000000000000000000");
    // await sleep(20000);
    //const b1 = await usr.balanceOf(pair.address);
    // console.log("usr bal", b1.toString());


    //create usr_usdt pair
    const fac1 = await Factory.at(factory);
    await fac1.createPair(usr_addr, usdt_addr);
    const usr_usdt_pair = await fac1.getPair(usr_addr,usdt_addr);
    console.log("get usr_usdt_pair:", usr_usdt_pair);
    const usr_usdt_pair_inst = await Pair.at(usr_usdt_pair);
    //add liquility
    await usdt.transfer(usr_usdt_pair, "100000000");
    await usr.transfer(usr_usdt_pair, "100000000000000000000");
    await sleep(40000);
    await pair.mint(owner);
    await usr_usdt_pair_inst.mint(owner);
    await sleep(30000);
    //deploy oracle
    const Tar_usr_oracle = await hre.ethers.getContractFactory("UniswapPairOracle");
    const _tar_usr_oracle = await Tar_usr_oracle.deploy(factory, usr_addr, tar_addr, owner, _time_lock, 1);
    await _tar_usr_oracle.deployed();
    console.log("Tar_usr_oracle deployed to:", _tar_usr_oracle.address);
    const usr_usd_oracle = await hre.ethers.getContractFactory("UniswapPairOracle");
    const _usr_usd_oracle = await usr_usd_oracle.deploy(factory, usr_addr, usdt.address, owner, _time_lock, 1);
    await _usr_usd_oracle.deployed();
    console.log("usr_usd_oracle deployed to:", _usr_usd_oracle.address);
    const tar_usr_24H_oracle = await hre.ethers.getContractFactory("UniswapPairOracle");
    const _tar_usr_24H_oracle = await tar_usr_24H_oracle.deploy(factory, usr_addr, tar_addr, owner, _time_lock, 24 * 3600);
    await _tar_usr_24H_oracle.deployed();
    console.log("_tar_usr_24H_oracle deployed to:", _tar_usr_24H_oracle.address);
    const usr_usd_24H_oracle = await hre.ethers.getContractFactory("UniswapPairOracle");
    const _usr_usd_24H_oracle = await usr_usd_24H_oracle.deploy(factory, usr_addr, usdt.address, owner, _time_lock, 24 * 3600);
    await _usr_usd_24H_oracle.deployed();
    console.log("_usr_usd_24H_oracle deployed to:", _usr_usd_24H_oracle.address);

    await usr.setOracleAddress(_tar_usr_oracle.address, _usr_usd_oracle.address, _tar_usr_24H_oracle.address, _usr_usd_24H_oracle.address);
    await pool.setPoolParameters("1000000000000000000000000", '0', 2, 0, 1194, 5500, 5500, '1000000000000000000000000',_time_lock);

    //set Chainlink oracle
    const oracle = await hre.ethers.getContractFactory("ChainlinkETHUSDPriceConsumerTest");
    const ethUsd = await oracle.deploy();
    await ethUsd.deployed();
    await usr.setETHUSDOracle(ethUsd.address);
    console.log("ethusd oracle address:", ethUsd.address);

    const Weth = await hre.ethers.getContractFactory("WETH");
    const weth = await Weth.deploy(owner);
    await weth.deployed();
    console.log("weth:", weth.address);
    let weth_address = weth.address;
    let coll_address = usdt.address;
    await fac1.createPair(weth_address, coll_address);
    const weth_usdt_pair = await fac1.getPair(weth_address, coll_address);
    console.log("get weth_usdt_pair:", weth_usdt_pair);
    const weth_usdt_pair_inst = await Pair.at(weth_usdt_pair);

    await usdt.transfer(weth_usdt_pair, "59000000000");
    await weth.transfer(weth_usdt_pair, "100000000000000000000");
    await sleep(30000);
    await weth_usdt_pair_inst.mint(owner);

    const Weth_Usdc_oracle = await hre.ethers.getContractFactory("UniswapPairOracle_USDC_WETH");
    const weth_Usdc_oracle = await Weth_Usdc_oracle.deploy(factory, weth_address, coll_address, owner, _time_lock);
    await weth_Usdc_oracle.deployed();

    console.log("weth_Usdc_oracle:", weth_Usdc_oracle.address);

    await pool.setCollatETHOracle(weth_Usdc_oracle.address, weth_address);


    // npx hardhat run --network ropsten scripts/sample-script.js
    // npx hardhat run --network rinkeby scripts/sample-script.js
    // npx hardhat verify --network rinkeby 0xb41133a368CC9EE67a807a331dde6deC92C521a8 "0x442a05a9B2d5883ee1418d9411250E29021ca48C" "0x024C79c199C09104e43A89e457e7491f3548B9cA" "0x740012c9ca86f49f324de5de783b477d19fe3ea2" "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x8412ebf45bac1b340bbe8f318b928c466c4e39ca"
    // const owner = "0x2287374e8d7090214628adad44Ff1ab56b9284D1";
    // const factory = "0x5c69bee701ef814a2b6a3edd4b1652cb9cc5aa6f";
    // const _time_lock = "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"

    //Usr
    //npx hardhat verify --network rinkeby 0xE92f6D3a3ccC891EB22128552b3Cc62214321042 "USR" "USR" "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"
    //tar
    //npx hardhat verify --network rinkeby 0xeF82D1741F580a52a2a336F36790285be2388983 "tollar"  "TAR"  "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"
    //pool
    //npx hardhat verify --network rinkeby 0xf32ae14C2D4b240e236f2bd13F080EB48e96EBAA "0x7d0Cb72b9FB22583De7e21b51fa8A8cf63Aa1953"  "0xb262027d67bc5E4178d63d26d2e086ABF991452A" "0xc87CeeFFB21751B9fb34c0Ad88B530157757E072" "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"
    //UsrIncentive
    //npx hardhat verify --network rinkeby  0xDB3ba788f23F21410a34700f5BdF7360bC8e9072 "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43" "0x7d0Cb72b9FB22583De7e21b51fa8A8cf63Aa1953" "0xb262027d67bc5E4178d63d26d2e086ABF991452A"

   // usdc
   // npx hardhat verify --network rinkeby 0xc87CeeFFB21751B9fb34c0Ad88B530157757E072 "Usdc" "USDC"


//weth_Usdc_oracle

   //npx hardhat verify --contract "contracts/Oracle/Variants/UniswapPairOracle_USDC_WETH.sol:UniswapPairOracle_USDC_WETH" --network rinkeby "0x497Ec0531BF2C02E48099397FA8E909E758a7aC1"  "0x5c69bee701ef814a2b6a3edd4b1652cb9cc5aa6f"  "0xaE285CD81D3c27D30c6abb49cbD7C37AE7691bAF" "0xD1d670121FC2204A3249417e503978541C857c55" "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"

}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error(error);
        process.exit(1);
    });
