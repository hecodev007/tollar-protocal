// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
const hre = require("hardhat");
const BigNumber = require('bignumber.js');

async function main() {

    // const oracle = await hre.ethers.getContractFactory("ChainlinkETHUSDPriceConsumerTest");
    // const ethUsd = await oracle.deploy();
    // await ethUsd.deployed();
    //await usr.setETHUSDOracle(ethUsd.address);
    // console.log("ethusd oracle address:", ethUsd.address);
    // let usr_addr = '0xDad785c864db82e79Fd410BDcDCD19900a69e09A';
    // const Usr = artifacts.require("UsrStablecoin");
    // const usr = await Usr.at(usr_addr);
    // const CollateralValue = await usr.globalCollateralValue();
    // console.log("CollateralValue:",CollateralValue.toString());
    // const uInfo = await usr.Usr_info();
    // console.log("info:",uInfo[0].toString())
    // collat_eth_oracle_address

    // const Pool = artifacts.require("UsrPool");
    // let pool_addr = '0x0C702EAD8b654Cd92d277eaFE5924Ad24915a65a';
    // let pool = await Pool.at(pool_addr);
    //
    // let colBal = await pool.collatDollarBalance();
    // console.log("colBal:", colBal.toString());


    /* const owner = "0x2287374e8d7090214628adad44Ff1ab56b9284D1";
     const factory = "0x5c69bee701ef814a2b6a3edd4b1652cb9cc5aa6f";
     const _time_lock = "0x07cB5cD417d8EB9373849e8F482Cb2031d9F1e43"

     const Factory = artifacts.require("UniswapV2Factory");
     const Pair = artifacts.require("UniswapV2Pair");

     const UsToken = artifacts.require("UsToken");
     const Weth = await hre.ethers.getContractFactory("WETH");
     const weth = await Weth.deploy(owner);
     await weth.deployed();
     console.log("weth:", weth.address);
     let usdc = '0xA8792aF30796A99C573B2E1B81b32582b1AF814f';

     const fac1 = await Factory.at(factory);
     await fac1.createPair(weth.address, usdc);
     const weth_usdc_pair = await fac1.getPair(weth.address, usdc);
     console.log("getPair:", weth_usdc_pair);
     const weth_usdc_pair_inst = await Pair.at(weth_usdc_pair);
     //add liquility

     const us = await UsToken.at(usdc);
     await us.transfer(weth_usdc_pair, "100000000000000000000");
     await weth.transfer(weth_usdc_pair, "100000000000000000000");
     await sleep(30000);
     await weth_usdc_pair_inst.mint(owner);

     const Weth_Usdc_oracle = await hre.ethers.getContractFactory("UniswapPairOracle_USDC_WETH");
     const weth_Usdc_oracle = await Weth_Usdc_oracle.deploy(factory, weth.address, usdc, owner, _time_lock);
     await weth_Usdc_oracle.deployed();

     console.log("weth_Usdc_oracle:", weth_Usdc_oracle.address);


     const Pool = artifacts.require("UsrPool");
     let pool_addr = '0x0C702EAD8b654Cd92d277eaFE5924Ad24915a65a';
     let pool = await Pool.at(pool_addr);
     await pool.setCollatETHOracle(weth_Usdc_oracle.address, weth.address);
 */

    const Oracle = artifacts.require("UniswapPairOracle_USDC_WETH");
    const weth_Usdc_oracle = await Oracle.at("0x83eB04f82d862b0859bbC6Ef13e643c6860Ca002");
    const b = await weth_Usdc_oracle.canUpdate();
    console.log("can update:", b);
    await weth_Usdc_oracle.update();



    // npx hardhat run --network ropsten scripts/sample-script.js
    // npx hardhat run --network rinkeby scripts/oracle.js
    // npx hardhat verify --network bsc_test 0xb41133a368CC9EE67a807a331dde6deC92C521a8 "0x442a05a9B2d5883ee1418d9411250E29021ca48C" "0x024C79c199C09104e43A89e457e7491f3548B9cA" "0x740012c9ca86f49f324de5de783b477d19fe3ea2" "0x2287374e8d7090214628adad44Ff1ab56b9284D1" "0x8412ebf45bac1b340bbe8f318b928c466c4e39ca"

}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// We recommend this pattern to be able to use async/await everywhere
// and properly handle errors.
main()
    .then(() => process.exit(0))
    .catch(error => {
        console.error(error);
        process.exit(1);
    });
